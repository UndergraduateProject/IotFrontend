import React, { useEffect, useState } from "react";
import api from './utils/api';

function verify(){
    api.post()
}