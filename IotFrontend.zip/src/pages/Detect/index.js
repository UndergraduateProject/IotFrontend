import React from "react"
import "bootstrap/dist/css/bootstrap.min.css"
import "./detect.css"
import detect_pc1 from "../../images/detect_pc1.png";
import ProgressBar from 'react-bootstrap/ProgressBar'


function Detect() {

    return (
        <div className="detect_body">
            <ProgressBar animated now={50} />
            <img className="detect_pc1" src={detect_pc1}/> 
            <div className="detect_background"> </div>

       
       
       
       
       
       
       
       
       
       
       
       
        </div>
    
        

        )
    }
    
export default Detect;
           